pkg install python -y
pkg install nodejs -y
pip install pycryptodome
